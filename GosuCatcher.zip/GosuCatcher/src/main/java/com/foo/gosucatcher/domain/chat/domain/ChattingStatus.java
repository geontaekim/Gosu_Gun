package com.foo.gosucatcher.domain.chat.domain;

public enum ChattingStatus {
	PENDING, ENTER, TALK
}
