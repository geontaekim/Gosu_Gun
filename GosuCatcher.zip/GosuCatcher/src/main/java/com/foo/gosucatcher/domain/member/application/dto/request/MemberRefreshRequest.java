package com.foo.gosucatcher.domain.member.application.dto.request;

public record MemberRefreshRequest(
	String refreshToken
) {
}
