package com.foo.gosucatcher.domain.member.application.dto.response;

public record JwtReissueResponse(
	String accessToken
) {
}
